<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "maissaber";

    $conn = new mysqli($servername, $username, $password, $dbname );

    if($conn -> connect_error){
        die("Ocorreu um erro". $conn -> connect_error);

        function mensagem($texto, $tipo) {
            echo "<div class='alert alert-$tipo' role='alert'>
            $texto
            </div>";
        }
    }

    #function mostra_data($data) {
    #    $d = explode('-', $data);
    #    $escreve = $d[2] ."/" .$d[1] ."/" .d[0];
    #    return $escreve;
    #}

?>